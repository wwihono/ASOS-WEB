"use strict";

/**
 * Name: Winston Wihono, Chengjie Huang
 * Date: 6/2/2024
 * Section: CSE 154 AF
 *
 * This JS file is used to setup important backend functionality for our website.
 * It includes the setup and configuration of the Express server, middleware,
 * and route handlers. The application provides various endpoints to manage
 * user accounts, handle user authentication, and manage purchase history and analytics.
 *
 * Endpoints:
 * - GET /userInfo/:user: Retrieves user information based on the provided username.
 * - POST /register: Registers a new user account and stores the information in the database.
 * - POST /login: Verifies user login information against the stored user information.
 * - POST /logoff: Logs a user off the website.
 * - POST /addToHistory: Adds successful purchases to the server-side history and updates analytics.
 * - POST /retrieveHistory: Retrieves the purchase history for a specific user.
 * - POST /retrieveAnalytics: Retrieves the number of times an item has been purchased.
 *
 * Error Handling:
 * - Returns appropriate HTTP status codes and error messages for various failure scenarios.
 * - Logs server-side errors for debugging purposes.
 *
 * Dependencies:
 * - Express: Web framework for Node.js.
 * - SQLite: Database management library.
 * - Multer: Middleware for handling `multipart/form-data`
 * - Crypto: password encryption framework, provides cryptographic functionalities
 * - Other necessary libraries and middleware.
 */

/**
 * Constants
 */
const express = require("express");
const app = express();
const multer = require("multer");
const crypto = require("crypto");
const sqlite = require("sqlite");
const sqlite3 = require("sqlite3");
const path = require('path');
const good = 200;
const bad = 400;
const server = 500;
const port = 8000;

// initialize sql query var
let sql;

// for application/x-www-form-urlencoded
app.use(express.urlencoded({extended: true})); // built-in middleware
// for application/json
app.use(express.json()); // built-in middleware
// for multipart/form-data (required with FormData)
app.use(multer().none()); // requires the "multer" module

/**
 * Establishes and returns a connection to the User SQLite database.
 *
 * @returns {Promise<sqlite.Database>} - A promise that resolves to the database connection.
 * @throws {Error} - If there is an error establishing the connection.
 */
async function getUserDBConnection() {
  try {
    const db = await sqlite.open({
      filename: "users.db",
      driver: sqlite3.Database
    });
    return db;
  } catch (error) {
    throw error;
  }
}

/**
 * Encrypts a password and returns the salt and hash.
 * @param {string} password - The password to be hashed.
 * @returns {{salt: string, hash: string}} - An object containing the salt and hashed password.
 */
function hashPasswords(password) {

  const randomSalt = 16;

  // Generate a random salt
  const salt = crypto.randomBytes(randomSalt).toString('hex');

  // Hash the password with the salt
  const hash = crypto.createHmac('sha256', salt)
    .update(password)
    .digest('hex');

  return {salt, hash};
}

/**
 * Helper function to decrypt passwords
 * @param {String} password - inputted password
 * @param {salt} salt - salt used to decrypt password
 * @returns {hash} - decrypted hash
 */
function decryptPassword(password, salt) {
  let hash = crypto.createHmac('sha256', salt)
    .update(password)
    .digest('hex');
  return hash;
}

/**
 * Checks if a username already exists in the database.
 *
 * @param {sqlite.Database} db - The database connection.
 * @param {string} username - The username to check.
 * @returns {Promise<boolean>} - A promise that resolves to true if the username exists, else false
 */
async function checkExisting(db, username) {
  try {
    sql = `SELECT * FROM users WHERE username = ?;`;
    let existing = await db.get(sql, [username]);
    return !!existing;
  } catch (err) {
    throw err;
  }
}

/**
 * Updates login status of a user
 *
 * @param {sqlite.Database} db - The database connection.
 * @param {string} username - The username to update.
 * @param {boolean} status - The new login status.
 */
async function updateLogin(db, username, status) {
  try {
    sql = `UPDATE users SET is_login = ? WHERE username = ?;`;
    await db.run(sql, [status, username]);
  } catch (err) {
    throw err;
  }
}

/**
 * Updates analytics for a purchased item
 * @param {sqlite.Database} db - The database connection.
 * @param {string} itemName - The item to update.
 * @param {Integer} itemId - unique item id
 * @param {Integer} amount - amount of purchased items
 */
async function updatePurchaseAnalytics(db, itemName, itemId, amount) {
  try {

    // Make sure that the item being updated exists in the db, else create new entry
    sql = `SELECT * FROM analytics WHERE id = ?;`;
    let res = await db.get(sql, [itemId]);
    if (res !== undefined) {
      sql = `UPDATE analytics SET purchased = (purchased + 1) WHERE id = ?;`;
      await db.run(sql, [itemId]);
    } else {
      sql = `INSERT INTO analytics (id, name, purchased) VALUES (?, ?, ?);`;
      await db.run(sql, [itemId, itemName, amount]);
    }
  } catch (err) {
    throw err;
  }
}

/**
 * Check login status of a user
 * @param {sqlite.Database} db - The database connection.
 * @param {string} username - The username to check.
 * @returns {boolean} - true if user is logged in, else false
 */
async function checkLogin(db, username) {
  try {
    sql = `SELECT is_login FROM users WHERE username = ?;`;
    let res = await db.get(sql, [username]);
    return res.is_login;
  } catch (err) {
    throw err;
  }
}

// Get and Post endpoints

// GET endpoint to get user information
app.get("/userInfo/:user", async (req, res) => {
  try {
    let db = await getUserDBConnection();
    let user = req.params.user;

    if (user) {
      sql = `SELECT username, email FROM users WHERE username = ?;`;
      let userInfo = await db.get(sql, [user]);
      db.close();
      res.status(good).send(userInfo);
    } else {
      db.close();
      res.status(bad)
        .type("text")
        .send("user doesn't exist");
    }
  } catch (error) {
    res.status(server)
      .type("text")
      .send("something went wrong on the server");
  }
});

// POST endpoint to log a user off the website
app.post("/logoff", async (req, res) => {

  try {
    let db = await getUserDBConnection();
    let username = req.body.username;
    if (await checkExisting(db, username)) {
      const isLogin = await checkLogin(db, username);
      if (isLogin === 1) {
        await updateLogin(db, username, false);
        db.close();
        res.status(good).send("User successfully logged off");
      } else {
        db.close();
        res.status(bad).send("User already logged off");
      }
    } else {
      db.close();
      res.status(bad).send("User does not exist");
    }
  } catch (error) {
    res.status(server).send("something went wrong on the server");
  }
});

// POST endpoint to register a new account and store it inside the db
app.post("/register", async (req, res) => {
  try {
    let db = await getUserDBConnection();
    let username = req.body.username;
    let password = req.body.password;
    let email = req.body.email;

    if (username && password && email) {
      if (!(await checkExisting(db, username))) {
        sql = "INSERT INTO users (username, salt, hash, is_login, email) VALUES (?, ?, ?, ?, ?);";
        let {salt, hash} = hashPasswords(password);
        await db.run(sql, [username, salt, hash, false, email]);
        db.close();
        res.status(good).send("User registered successfully");
      } else {
        db.close();
        res.status(bad).send("User with this name already exists");
      }
    } else {
      db.close();
      res.status(bad).send("Missing one or more parameters");
    }
  } catch (error) {
    res.status(server).send("something went wrong on the server");
  }
});

// POST endpoint to allow users to login
app.post("/login", async (req, res) => {
  let db = await getUserDBConnection();
  const {username, password} = req.body;

  if (!username || !password) {
    res.status(bad).send("Missing credentials");
    db.close();
    return;
  }

  sql = `SELECT salt, hash FROM users WHERE username = ?;`;
  const user = await db.get(sql, [username]);

  if (!user) {
    res.status(bad).send("User doesn't exist");
    db.close();
    return;
  }

  if (await checkLogin(db, username)) {
    res.status(bad).send("User already logged in");
    db.close();
    return;
  }

  const hash = decryptPassword(password, user.salt);
  if (hash !== user.hash) {
    res.status(bad).send("Incorrect password");
    db.close();
    return;
  }

  await updateLogin(db, username, true);
  res.status(good).send("Successful login");
  db.close();
});

/**
 * POST endpoint to adds successful purchases to the serverside purchase history and updates
 * analytics table
 */
app.post('/addToHistory', async (req, res) => {
  try {
    let db = await getUserDBConnection();
    let {price, name: itemName, amount, username, id: itemId} = req.body;

    if (price && itemName && username && amount && itemId) {
      if (await checkExisting(db, username)) {
        if (await checkLogin(db, username)) {
          sql = `INSERT INTO history (username, name, price, amount) VALUES (?, ?, ?, ?);`;
          await db.run(sql, [username, itemName, price * amount, amount]);
          await updatePurchaseAnalytics(db, itemName, itemId, amount);
          db.close();
          res.status(good)
            .type("text")
            .send("Added to purchase history");
        } else {
          db.close();
          res.status(bad).send("User not logged in");
        }
      } else {
        db.close();
        res.status(bad).send("User not registered");
      }
    } else {
      db.close();
      res.status(bad).send("Missing one or more parameters");
    }
  } catch (error) {
    res.status(server).send("something went wrong on the server");
  }
});

// POST endpoint to retrieve a specific user's purchase history
app.post(`/retrieveHistory`, async (req, res) => {
  try {
    let db = await getUserDBConnection();
    let username = req.body.username;
    if (username) {
      if (await checkLogin(db, username)) {
        sql = `SELECT * FROM history WHERE username = ?;`;
        let history = await db.all(sql, [username]);
        db.close();
        res.status(good).send(history);
      } else {
        db.close();
        res.status(bad).send("Please login to view transaction history");
      }
    } else {
      db.close();
      res.status(bad).send("Missing username");
    }
  } catch (error) {
    res.status(server).send("something went wrong on the server");
  }
});

// POST endpoint to retrieve a specific user's purchase history DESCENDING
app.post(`/retrieveHistoryNewest`, async (req, res) => {
  try {
    let db = await getUserDBConnection();
    let username = req.body.username;
    if (username) {
      if (await checkLogin(db, username)) {
        sql = `SELECT * FROM history WHERE username = ? ORDER BY ID DESC;`;
        let history = await db.all(sql, [username]);
        db.close();
        res.status(good).send(history);
      } else {
        db.close();
        res.status(bad).send("Please login to view transaction history");
      }
    } else {
      db.close();
      res.status(bad).send("Missing username");
    }
  } catch (error) {
    res.status(server).send("something went wrong on the server");
  }
});

// GET endpoint to retrieve how many times an item has been purchased
app.get('/retrieveAnalytics', async (req, res) => {
  try {
    let db = await getUserDBConnection();
    sql = `SELECT id FROM analytics ORDER BY purchased DESC;`;
    let result = await db.all(sql);

    db.close();
    res.status(good).json(result);
  } catch (error) {
    res.status(server).send("something went wrong on the server");
  }
});

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));
const PORT = process.env.PORT || port;
app.listen(PORT);