"use strict";

/**
 * Name: Chengjie Huang, Winston Wihono
 * Date: 05.05.2024
 * Section: CSE 154 AF
 *
 * This JS file is use to mainly setup nav bar buttons,
 * buttons in index.html, and the recommendation section in index.html.
 */
(function() {

  /**
   * Constants
   */
  const MS_PER_SEC = 1000;
  const ANALYTIC_URL = "/retrieveAnalytics";
  const SEARCH_OPTS = {
    method: 'GET',
    headers: {
      'X-RapidAPI-Key': '60323db40bmsheadfcc584a62314p1c5228jsn0b609d0056ae',
      'X-RapidAPI-Host': 'asos2.p.rapidapi.com'
    }
  };

  addListen("load", window, init);

  /**
   * Initializes the navigation selections and sets up recommendations.
   */
  function init() {
    if (qs(".item-display") !== null) {
      const itemDisplays = qsa(".item-display");
      let btn = itemDisplays[0].querySelector("button");
      addListen("click", btn, () => {
        search("men coat");
        window.location.replace("./search.html");
      });
      btn = itemDisplays[1].querySelector("button");
      addListen("click", btn, () => {
        search("women jacket");
        window.location.replace("./search.html");
      });
    }
    const selections = qs("nav").children[0].querySelector("ul").children;
    for (let i = 0; i < selections.length; i++) {
      const seachTerm = selections[i].innerText;
      addListen("click", selections[i].querySelector("a"), () => search(seachTerm));
    }
    setUpRecommendation();
  }

  /**
   * Stores the search term in session storage.
   * @param {string} searchTerm - The search term to be stored.
   */
  function search(searchTerm) {
    window.sessionStorage.setItem("to-search", searchTerm);
  }

  /**
   * Sets up the recommendation section by fetching and displaying recommended items.
   * items are filtered based on purchase count
   */
  async function setUpRecommendation() {
    const num = 4;
    const resultContainer = id("recommendation");
    if (resultContainer !== null) {
      resultContainer.innerHTML = "";
      const res = await makeRequest(null, null, ANALYTIC_URL, "GET");
      const numToDisplay = num < res.length ? num : res.length;
      for (let i = 0; i < numToDisplay; i++) {
        try {
          const asosRes = await fetchDetailAsos(res[i].id);
          const item = gen("article");
          item.id = res[i].id;
          item.classList.add("item");
          const img = gen("img");
          const imgs = asosRes.media.images;
          img.src = "https://" + imgs[i].url;
          img.alt = "Image of " + asosRes.name;
          addListen("click", img, displayDetail);
          const name = gen("p");
          name.innerText = asosRes.name;
          item.appendChild(img);
          item.appendChild(name);
          resultContainer.appendChild(item);
        } catch (err) {
          handleError(err);
        }
      }
    }
  }

  /**
   * Displays the details of an item by setting the item ID in session storage and
   * redirecting to the search page.
   */
  function displayDetail() {
    window.sessionStorage.setItem("to-display", this.parentElement.id);
    window.location.replace("./search.html");
  }

  /**
   * Fetches detailed information about an item from the ASOS API.
   * @param {string} id - The ID of the item to fetch details for.
   * @returns {json} - Json object containing item data
   */
  async function fetchDetailAsos(id) {
    const url = "https://asos2.p.rapidapi.com/products/v4/detail?id=" + id + "&lang=en-US&store=US&sizeSchema=US&currency=USD";
    try {
      const response = await fetch(url, SEARCH_OPTS);
      statusCheck(response);
      return await response.json();
    } catch (err) {
      handleError(err);
    }
  }

  /**
   * Make a request to the Pokemon API with the given parameters.
   * Also process the result after the request responded.
   * @param {string} key - the key(s) for the requesr parameter(s).
   * @param {string} value - the value(s) for the request parameter(s).
   * @param {string} URL - the endpoint url that we are sending the request to.
   * @param {string} method - HTTP method being use for this request.
   * @param {boolean} isJson - is the response in the form of JSON?
   * @returns {JSON} JSON representing the request response.
   * @returns {Text} Plain text representing the request response.
   */
  function makeRequest(key, value, URL, method, isJson = true) {
    if (method === "POST") {
      let data = new FormData();
      if (typeof key === "object") {
        for (let i = 0; i < key.length; i++) {
          data.append(key[i], value[i]);
        }
      } else {
        data.append(key, value);
      }
      return fetch(URL, {method: 'POST', body: data})
        .then(statusCheck)
        .then(res => {
          return isJson ? res.json() : res.text();
        })
        .catch(handleError);
    }
    let urlPrep = URL;
    if (key !== null && value !== null) {
      urlPrep += "?" + key + "=" + value;
    } else if (value !== null) {
      urlPrep += value;
    }
    return fetch(urlPrep, {method: 'GET'})
      .then(statusCheck)
      .then(res => {return isJson ? res.json() : res.text();})
      .catch(handleError);
  }

  /**
   * Check the if a response from a request is ok or not.
   * @param {Object} response - the response that is being check.
   * @returns {Object} the same response passed in.
   */
  async function statusCheck(response) {
    if (!response.ok) {
      throw new Error(await response.text());
    }
    return response;
  }

  /**
   * Add a event listener to a given element with a given event and function,
   * isOnce is use to indicate if the event listener is only activating
   * once.
   * @param {string} evt - the event the listener is listening for.
   * @param {HTMLElement} elem - the element the listener is attching to.
   * @param {Function} func - the function to run when event is detected.
   * @param {boolean} isOnce - Whether or not the event listener is only activating once.
   */
  function addListen(evt, elem, func, isOnce = false) {
    elem.addEventListener(evt, func, {once: isOnce});
  }

  /**
   * Gets the first instance of the element selected
   * @param {string} selector - HTML query selector
   * @returns {Element} - element associated with the selector
   */
  function qs(selector) {
    return document.querySelector(selector);
  }

  /**
   * Get a element by its id.
   * @param {string} id - id of the element that the user want to get.
   * @returns {HTMLElement} the element that the user want to get.
   * @returns {null} if the element doesn't exist in the DOM.
   */
  function id(id) {
    return document.getElementById(id);
  }

  /**
   * Create a new element by using the given tag name.
   * @param {string} el - tag name of a element.
   * @returns {HTMLElement} that the user want to generate.
   */
  function gen(el) {
    return document.createElement(el);
  }

  /**
   * Logs and throws errors to the console and displays an error message
   * This function is typically used to handle exceptions and display user-friendly error messages
   * when network requests or other critical operations fail.
   * @param {Error} error - The error object that contains information about the error encountered.
   */
  function handleError(error) {
    console.error("Failed to fetch data: ", error);
    displayMsg(error.message, true);
    throw error;
  }

  /**
   * Gets the all instance of the element selected
   * @param {string} selector - HTML query selector
   * @returns {Element} - element associated with the selector
   */
  function qsa(selector) {
    return document.querySelectorAll(selector);
  }

  /**
   * Displays a message to the user for a specified duration.
   * @param {string} msg - The message to be displayed.
   * @param {boolean} [isError=false] - Indicates if the message is an error message.
   */
  async function displayMsg(msg, isError = false) {
    const delay = 4;
    const newMsg = gen("p");
    newMsg.innerText = msg;
    if (isError) {
      newMsg.classList.add("error");
    } else {
      newMsg.classList.add("good");
    }
    id("msg-area").appendChild(newMsg);
    await pause(delay);
    id("msg-area").removeChild(newMsg);
  }

  /**
   * Pause the execution of a function for the given duration.
   * @param {number} secs - the amount of second we want to pause the game.
   * @returns {Promise} a promise that pauses the game until it resolves when
   * the timeout expires.
   */
  function pause(secs) {
    const promise = new Promise(res => {
      setTimeout(() => res("pause for " + secs + " second"), secs * MS_PER_SEC);
    });
    return promise;
  }
})();