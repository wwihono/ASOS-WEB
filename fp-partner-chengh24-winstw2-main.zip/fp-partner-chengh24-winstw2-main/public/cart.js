"use strict";

/**
 * Name: Chengjie Huang, Winston Wihono
 * Date: 05.05.2024
 * Section: CSE 154 AF
 *
 * This JS file is use to setup important functionality
 * for our website, how we are setting up those is unknown
 * as we are just working on the frontend currently.
 * Currently this file contain the code that setup the
 * image carousel in the product detail page.
 *
 */
(function() {

  /**
   * Constants
   */
  const MS_PER_SEC = 1000;
  const HIST_UPDATE_URL = "/addToHistory";

  let total = 0;

  addListen("load", window, init);

  /**
   * Initializes the cart page, displays cart items, and sets up event listeners.
   */
  function init() {
    displayCartItems();
    addListen("submit", id("info-form"), (evt) => {
      evt.preventDefault();
      checkOut();
    });
  }

  /**
   * Handles the checkout process. Verifies user information and processes each item in the cart.
   */
  async function checkOut() {
    if (!infoCheck()) {
      return;
    }
    const items = id("item-list").children;
    for (let i in items) {
      if (i.match(/^[0-9]+$/)) {
        const name = items[i].querySelector("p").innerText;
        let price = items[i].querySelector(".item-price").firstChild.innerText;
        price = price.substring(1);
        let amount = items[i].querySelector(".item-price").lastChild.innerText;
        amount = amount.split(" ")[1];
        const user = window.localStorage.getItem("current-user");
        const id = items[i].id;
        window.localStorage.removeItem(id);
        try {
          await makeRequest(["price", "name", "amount", "username", "id"], [price, name, amount,
                            user, id], HIST_UPDATE_URL, "POST", false);
        } catch (err) {
          return;
        }
      }
    }
    id("item-list").innerHTML = "";
    id("total").innerText = "Total: $0.00";
    displayMsg("Order Placed");
  }

  /**
   * Verifies user information, including credit card details and address.
   * @returns {boolean} - Returns true if all information is valid, otherwise false.
   */
  function infoCheck() {
    if (!checkoutPreReqCheck()) {
      return false;
    }
    let hasInvalid = false;
    const limit = 16;
    const [cardNum, exp, cvv] = ["card-num", "expiration", "cvv"].map(elementId => id(elementId));
    const length = cardNum.value.length;
    if (!cardNum.value.match(/^[0-9]+$/) || length < limit || length > limit) {
      displayMsg("Please enter a valid credit card number", true);
      hasInvalid = true;
    }
    if (!/^0[1-9]\/[0-9]{2}$/.test(exp.value) && !/^1[0-2]\/[0-9]{2}$/.test(exp.value)) {
      displayMsg("Please enter a valid credit card expiration date", true);
      hasInvalid = true;
    }
    if (!cvv.value.match(/^[0-9]{3}$/)) {
      displayMsg("Please enter a valid CVV number", true);
      hasInvalid = true;
    }
    [cardNum, exp, cvv].forEach(el => {
      el.value = "";
    });
    id("address").value = "";
    return !hasInvalid;
  }

  /**
   * Checks prerequisites for proceeding to checkout.
   * - Ensures there are items in the cart.
   * - Ensures a user is logged in.
   *
   * @returns {boolean} Returns false if any prerequisite is not met, otherwise return true.
   */
  function checkoutPreReqCheck() {
    if (id("item-list").children.length === 0) {
      displayMsg("You don't have any item in cart right now", true);
      return false;
    }
    if (window.localStorage.getItem("current-user") === null) {
      window.location.replace("./login.html");
      return false;
    }
    return true;
  }

  /**
   * Displays items stored in the local storage cart on the webpage.
   */
  function displayCartItems() {
    const itemList = id("item-list");
    itemList.innerHTML = "";
    for (let key in window.localStorage) {
      if (!isNaN(parseInt(key))) {
        const params = window.localStorage.getItem(key).split(",");

        total += parseInt(params[2]) * parseFloat(params[1].substring(1));

        itemList.appendChild(makeCartItem(
          key,
          params[0],
          params[2],
          params[3],
          params[1],
          params[4]
        ));
      }
    }
    id("total").innerText = "Total: $" + total.toFixed(2);
  }

  /**
   * Creates and returns a cart item element.
   * @param {string} id - The unique identifier for the cart item.
   * @param {string} name - The name of the item.
   * @param {string} amount - The quantity of the item.
   * @param {string} imgUrl - The URL of the item's image.
   * @param {string} price - The price of the item.
   * @param {string} alt - The alt text for the item's image.
   * @returns {HTMLElement} - The cart item element.
   */
  function makeCartItem(id, name, amount, imgUrl, price, alt) {
    const cartItem = gen("li");
    cartItem.classList.add("item-info");
    cartItem.id = id;
    const img = gen("img");
    const nameDisplay = gen("p");
    const itemRight = gen("div");
    img.src = imgUrl;
    img.alt = alt;
    nameDisplay.innerText = name;
    itemRight.classList.add("item-right");
    const priceDisplay = gen("div");
    priceDisplay.classList.add("item-price");
    const removeBtn = gen("button");
    removeBtn.innerText = "Remove";
    addListen("click", removeBtn, removeItem);
    const totalPrice = parseInt(amount) * parseFloat(price.substring(1));
    const priceText = gen("p");
    const amountDisplay = gen("p");
    priceText.innerText = "$" + totalPrice;
    amountDisplay.innerText = "Amount: " + parseInt(amount);
    priceDisplay.append(priceText, amountDisplay);
    itemRight.append(priceDisplay, removeBtn);
    cartItem.append(img, nameDisplay, itemRight);
    return cartItem;
  }

  /**
   * Removes an item from the cart and updates the total.
   */
  function removeItem() {
    const parent = this.parentElement.parentElement;
    const params = window.localStorage.getItem(parent.id).split(",");
    total -= parseInt(params[2]) * parseFloat(params[1].substring(1));
    id("total").innerText = "Total: $" + total.toFixed(2);
    window.localStorage.removeItem(parent.id);
    id("item-list").removeChild(parent);
    displayMsg("Removed " + params[0] + " from cart.");
  }

  /**
   * Displays a message to the user.
   * @param {string} msg - The message to display.
   * @param {boolean} [isError=false] - Indicates if the message is an error message.
   */
  async function displayMsg(msg, isError = false) {
    const delay = 4;
    const newMsg = gen("p");
    newMsg.innerText = msg;
    if (isError) {
      newMsg.classList.add("error");
    } else {
      newMsg.classList.add("good");
    }
    id("msg-area").appendChild(newMsg);
    await pause(delay);
    id("msg-area").removeChild(newMsg);
  }

  /**
   * Make a request to the API with the given parameters.
   * Also process the result after the request responded.
   * @param {string} key - the key(s) for the requesr parameter(s).
   * @param {string} value - the value(s) for the request parameter(s).
   * @param {string} URL - the endpoint url that we are sending the request to.
   * @param {string} method - HTTP method being use for this request.
   * @param {boolean} isJson - is the response in the form of JSON?
   * @returns {JSON} JSON representing the request response.
   * @returns {Text} Plain text representing the request response.
   */
  function makeRequest(key, value, URL, method, isJson = true) {
    if (method === "POST") {
      let data = new FormData();
      if (typeof key === "object") {
        for (let i = 0; i < key.length; i++) {
          data.append(key[i], value[i]);
        }
      } else {
        data.append(key, value);
      }
      return fetch(URL, {method: 'POST', body: data})
        .then(statusCheck)
        .then(res => {
          return isJson ? res.json() : res.text();
        })
        .catch(handleError);
    }
    let urlPrep = URL;
    if (key !== null && value !== null) {
      urlPrep += "?" + key + "=" + value;
    } else if (value !== null) {
      urlPrep += value;
    }
    return fetch(urlPrep, {method: 'GET'})
      .then(statusCheck)
      .then(res => {return isJson ? res.json() : res.text();})
      .catch(handleError);
  }

  /**
   * If there's a error, show the error view and disable all the buttons in the
   * Nav bar.
   * @param {Error} err - error object being thrown
   */
  function handleError(err) {
    displayMsg(err.message, true);
    throw err;
  }

  /**
   * Check the if a response from a request is ok or not.
   * @param {Object} response - the response that is being check.
   * @returns {Object} the same response passed in.
   */
  async function statusCheck(response) {
    if (!response.ok) {
      throw new Error(await response.text());
    }
    return response;
  }

  /**
   * Pause the execution of a function for the given duration.
   * @param {number} secs - the amount of second we want to pause the game.
   * @returns {Promise} a promise that pauses the game until it resolves when
   * the timeout expires.
   */
  function pause(secs) {
    const promise = new Promise(res => {
      setTimeout(() => res("pause for " + secs + " second"), secs * MS_PER_SEC);
    });
    return promise;
  }

  /**
   * Create a new element by using the given tag name.
   * @param {string} el - tag name of a element.
   * @returns {HTMLElement} that the user want to generate.
   */
  function gen(el) {
    return document.createElement(el);
  }

  /**
   * Get a element by its id.
   * @param {string} id - id of the element that the user want to get.
   * @returns {HTMLElement} the element that the user want to get.
   * @returns {null} if the element doesn't exist in the DOM.
   */
  function id(id) {
    return document.getElementById(id);
  }

  /**
   * Add a event listener to a given element with a given event and function,
   * isOnce is use to indicate if the event listener is only activating once.
   * @param {string} evt - the event the listener is listening for
   * @param {HTMLElement} elem - the element the listener is attching to
   * @param {Function} func - the function to run when event is detected
   * @param {boolean} isOnce - whether or not the event listener is only activating once
   */
  function addListen(evt, elem, func, isOnce = false) {
    elem.addEventListener(evt, func, {once: isOnce});
  }
})();