"use strict";

/**
 * Name: Chengjie Huang, Winston Wihono
 * Date: 05.05.2024
 * Section: CSE 154 AF
 *
 * This script manages the purchase history functionality of the web application.
 * It includes functions to check for a logged-in user, retrieve and display their purchase history,
 * and handle any errors that occur during these processes.
 */
(function() {

  /**
   * Constants
   */
  const MS_PER_SEC = 1000;
  const purchaseHistory = `/retrieveHistory`;

  addListen("load", window, init);

  /**
   * Initializes the application by checking if a user is logged in,
   * populating their purchase history, and handling filtering purchase history entries by date.
   */
  async function init() {
    if (checkLogin() !== null) {
      await populateHistory(); // if a user is logged in, then retrieve their purchase history
      id("most-recent").addEventListener("change", filterRecent);
      id("oldest").addEventListener("change", filterOldest);
    } else {
      displayError();
    }
  }

  /**
   * Filters the purchase history to show the most recent purchases.
   * @param {Event} event - The change event triggered by the checkbox.
   */
  async function filterRecent(event) {
    if (event.target.checked) {
      id("oldest").checked = false;
      let res = await makeRequest(["username"], [checkLogin()], `/retrieveHistoryNewest`, `POST`);
      await populateHistoryRecent(res);
    }
  }

  /**
   * Filters the purchase history to show the oldest purchases.
   * @param {Event} event - The change event triggered by the checkbox.
   */
  async function filterOldest(event) {
    if (event.target.checked) {
      id("most-recent").checked = false;
      await populateHistory();
    }
  }

  /**
   * Displays an error message and redirects the user to the login page
   * if they are not logged in.
   */
  function displayError() {
    window.sessionStorage.setItem("errorMsg", "Please login to view purchase history");
    let currentPath = window.location.pathname;
    let origin = window.location.origin;
    let redirectUrl;

    if (currentPath.includes('/html/')) {
      let lastIndexHtml = currentPath.substring(0, currentPath.lastIndexOf('/html/'));
      redirectUrl = origin + lastIndexHtml + '/html/login.html';
    } else {
      redirectUrl = origin + '/html/login.html';
    }
    setTimeout(() => {
      window.location.href = redirectUrl;
    }, MS_PER_SEC);
  }

  /**
   * Checks if a user is logged into the website
   * @returns {string|null} The current user if logged in, otherwise null.
   */
  function checkLogin() {
    return window.localStorage.getItem("current-user");
  }

  /**
   * Populates the purchase history with purchase history entries sorted by oldest
   */
  async function populateHistory() {
    const listPurchases = document.querySelector(".item-list");
    listPurchases.innerHTML = ""; // Clear any existing elements
    let currentUser = window.localStorage.getItem("current-user");

    try {
      let res = await makeRequest(["username"], [currentUser], purchaseHistory, "POST");
      res.forEach(entry => {
        generateNewListItem(entry, listPurchases);
      });
    } catch (error) {
      console.error(error);
    }
  }

  /**
   * Populates the purchase history list sorted by most recent purchases
   * @param {Array} res - The array of purchase history items.
   */
  function populateHistoryRecent(res) {
    const listPurchases = document.querySelector(".item-list");
    listPurchases.innerHTML = ""; // Clear any existing elements

    try {
      res.forEach(entry => {
        generateNewListItem(entry, listPurchases);
      });
    } catch (error) {
      console.error(error);
    }
  }

  /**
   * Generates a new list item for the purchase history.
   * @param {Object} entry - The purchase history entry.
   * @param {HTMLElement} list - The list element to append the new item to.
   */
  function generateNewListItem(entry, list) {
    let listItem = document.createElement("li");
    listItem.classList.add("item-info");

    // Create and append the description paragraph
    let description = document.createElement("p");
    description.textContent = entry.name || "Default name";
    listItem.appendChild(description);

    // Create and append the item-right div
    let itemRightDiv = document.createElement("div");
    itemRightDiv.classList.add("item-right");

    // Create and append the item-price div
    let itemPriceDiv = document.createElement("div");
    itemPriceDiv.classList.add("item-price");

    let price = document.createElement("p");
    price.textContent = `$${entry.price.toFixed(2)}`; // Format price to 2 decimal places
    itemPriceDiv.appendChild(price);

    let amount = document.createElement("p");
    amount.textContent = `Amount: ${entry.amount}`;
    itemPriceDiv.appendChild(amount);

    itemRightDiv.appendChild(itemPriceDiv);

    // Create and append the purchase time
    let time = document.createElement("p");
    time.textContent = (entry.time + " GMT") || "Time not available";
    itemRightDiv.appendChild(time);

    listItem.appendChild(itemRightDiv);
    list.appendChild(listItem);
  }

  /**
   * Make a request to the API with the given parameters.
   * Also process the result after the request responded.
   * @param {string} key - the key(s) for the requesr parameter(s).
   * @param {string} value - the value(s) for the request parameter(s).
   * @param {string} URL - the endpoint url that we are sending the request to.
   * @param {string} method - HTTP method being use for this request.
   * @param {boolean} isJson - is the response in the form of JSON?
   * @returns {JSON} JSON representing the request response.
   * @returns {Text} Plain text representing the request response.
   */
  function makeRequest(key, value, URL, method, isJson = true) {
    if (method === "POST") {
      let data = new FormData();
      if (typeof key === "object") {
        for (let i = 0; i < key.length; i++) {
          data.append(key[i], value[i]);
        }
      } else {
        data.append(key, value);
      }
      return fetch(URL, {method: 'POST', body: data})
        .then(statusCheck)
        .then(res => {
          return isJson ? res.json() : res.text();
        })
        .catch(handleError);
    }
    let urlPrep = URL;
    if (key !== null && value !== null) {
      urlPrep += "?" + key + "=" + value;
    } else if (value !== null) {
      urlPrep += value;
    }
    return fetch(urlPrep, {method: 'GET'})
      .then(statusCheck)
      .then(res => {return isJson ? res.json() : res.text();})
      .catch(handleError);
  }

  /**
   * Logs errors to the console and displays an error message
   * This function is typically used to handle exceptions and display user-friendly error messages
   * when network requests or other critical operations fail.
   * @param {Error} error - The error object that contains information about the error encountered.
   */
  function handleError(error) {
    console.error("Failed to fetch data: ", error);
    displayMsg(error.message, true);
  }

  /**
   * Check the if a response from a request is ok or not.
   * @param {Object} response - the response that is being check.
   * @returns {Object} the same response passed in.
   */
  async function statusCheck(response) {
    if (!response.ok) {
      throw new Error(await response.text());
    }
    return response;
  }

  /**
   * Add a event listener to a given element with a given event and function,
   * isOnce is use to indicate if the event listener is only activating
   * once.
   * @param {string} evt - the event the listener is listening for.
   * @param {HTMLElement} elem - the element the listener is attching to.
   * @param {Function} func - the function to run when event is detected.
   * @param {boolean} isOnce - Whether or not the event listener is only activating once.
   */
  function addListen(evt, elem, func, isOnce = false) {
    elem.addEventListener(evt, func, {once: isOnce});
  }

  /**
   * Displays a message to the user for a specified duration.
   * @param {string} msg - The message to be displayed.
   * @param {boolean} [isError=false] - Indicates if the message is an error message.
   */
  async function displayMsg(msg, isError = false) {
    const delay = 4;
    const newMsg = gen("p");
    newMsg.innerText = msg;
    if (isError) {
      newMsg.classList.add("error");
    } else {
      newMsg.classList.add("good");
    }
    id("msg-area").appendChild(newMsg);
    await pause(delay);
    id("msg-area").removeChild(newMsg);
  }

  /**
   * Pause the execution of a function for the given duration.
   * @param {number} secs - the amount of second we want to pause the game.
   * @returns {Promise} a promise that pauses the game until it resolves when
   * the timeout expires.
   */
  function pause(secs) {
    const promise = new Promise(res => {
      setTimeout(() => res("pause for " + secs + " second"), secs * MS_PER_SEC);
    });
    return promise;
  }

  /**
   * Get a element by its id.
   * @param {string} id - id of the element that the user want to get.
   * @returns {HTMLElement} the element that the user want to get.
   * @returns {null} if the element doesn't exist in the DOM.
   */
  function id(id) {
    return document.getElementById(id);
  }

  /**
   * Create a new element by using the given tag name.
   * @param {string} el - tag name of a element.
   * @returns {HTMLElement} that the user want to generate.
   */
  function gen(el) {
    return document.createElement(el);
  }
})();