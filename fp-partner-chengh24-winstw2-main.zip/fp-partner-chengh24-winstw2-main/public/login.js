"use strict";

/**
 * Name: Chengjie Huang, Winston Wihono
 * Date: 05.05.2024
 * Section: CSE 154 AF
 *
 * This JS file is use to setup important functionality
 * for our website, how we are setting up those is unknown
 * as we are just working on the frontend currently.
 * Currently this file contain the code that setup the
 * image carousel in the product detail page.
 */
(function() {

  /**
   * TODO: maybe move this carousel setup to another js file
   */
  addListen("load", window, init);

  /**
   * Constants
   */
  const SIGN_UP_URL = "/register";
  const SIGN_OUT_URL = "/logoff";
  const LOGIN_URL = "/login";
  const GET_USER_URL = "/userInfo/";
  const MS_PER_SEC = 1000;

  /**
   * Initializes event listeners for various buttons and sets up the profile view.
   */
  function init() {
    if (window.sessionStorage.getItem("errorMsg") !== null) {
      displayMsg(window.sessionStorage.getItem("errorMsg"), true);
      window.sessionStorage.removeItem("errorMsg");
    }
    addListen("click", id("back-btn"), toggleSignUp);
    addListen("click", id("to-sign-up-btn"), toggleSignUp);
    addListen("submit", id("sign-in-view"), (evt) => {
      evt.preventDefault();
      signIn();
    });
    addListen("submit", qs("#sign-up-view form"), (evt) => {
      evt.preventDefault();
      signUp();
    });
    addListen("click", id("sign-out-btn"), signOut);
    setUpProfile();
  }

  /**
   * Toggles between the sign-up and sign-in views.
   */
  function toggleSignUp() {
    if (id("sign-up-view").style.display === "none") {
      qs("h1").innerText = "Create Your Account";
      hide(id("sign-in-view"));
      show(id("sign-up-view"), "flex");
    } else {
      qs("h1").innerText = "Sign In";
      show(id("sign-in-view"), "flex");
      hide(id("sign-up-view"));
    }
  }

  /**
   * Handles the sign-in process, including validation and API requests.
   * @returns {undefined} - returns undefine if it detected invalid input.
   */
  async function signIn() {
    let hasInvalid = false;
    if (!checkInput("username", "username")) {
      hasInvalid = true;
    }
    if (!checkInput("password", "password")) {
      hasInvalid = true;
    }
    if (hasInvalid) {
      return;
    }
    const username = id("username").value;
    try {
      const res = await makeRequest(
        ["username", "password"],
        [username, id("password").value],
        LOGIN_URL,
        "POST",
        false
      );
      id("username").value = "";
      id("password").value = "";
      window.localStorage.setItem("current-user", username);
      await setUpProfile();
      displayMsg(res);
    } catch (err) {
      throw err;
    }
  }

  /**
   * Handles the sign-up process, including validation and API requests.
   * @returns {undefined} - detected invalid inputs.
   */
  async function signUp() {
    if (!checkInput("email", "email", true) || !checkInput("new-username", "username") ||
      !checkInput("new-password", "password")) {
      return;
    }
    const [username, password, email] = ["new-username", "new-password", "email"]
      .map(elementId => id(elementId).value);
    try {
      const res = await makeRequest(
        ["username", "password", "email"],
        [username, password, email],
        SIGN_UP_URL,
        "POST",
        false
      );
      displayMsg(res);
    } catch (err) {
      throw err;
    }
    id("email").value = "";
    id("new-username").value = "";
    id("new-password").value = "";
    qs("h1").value = "Sign In";
    hide(id("sign-up-view"));
    show(id("sign-in-view"), "flex");
  }

  /**
   * Handles the sign-out process and updates the UI accordingly.
   */
  async function signOut() {
    try {
      await makeRequest(
        "username",
        window.localStorage.getItem("current-user"),
        SIGN_OUT_URL,
        "POST",
        false
      );
      window.localStorage.removeItem("current-user");
      qs("h1").innerText = "Sign In";
      leaveProfileView();
      displayMsg("Sign out sucessful");
    } catch (err) {
      leaveProfileView();
      window.localStorage.removeItem("current-user");
      throw err;
    }
  }

  /**
   * Sets up the profile view by fetching user data and updating the UI.
   */
  async function setUpProfile() {
    if (window.localStorage.getItem("current-user") !== null) {
      try {
        const res = await makeRequest(
          null,
          window.localStorage.getItem("current-user"),
          GET_USER_URL,
          "GET"
        );
        id("user-username").innerText = res.username;
        id("user-email").innerText = res.email;
        qs("h1").innerText = "Profile";
        qs("#profile-view h2").innerText = "Currently logged in as " + res.username;
        toProfileView();
      } catch (err) {
        throw err;
      }
    }
  }

  /**
   * Checks the validity of input fields.
   * @param {string} inputId - The ID of the input element.
   * @param {string} inputType - The type of the input (e.g., username, password, email).
   * @param {boolean} [isEmail=false] - Whether the input is an email.
   * @returns {boolean} - True if the input is valid, false otherwise.
   */
  function checkInput(inputId, inputType, isEmail = false) {
    const value = id(inputId).value;
    if (value.trim() === "") {
      displayMsg("Missing " + inputType + ", please enter a valid " + inputType, true);
      return false;
    }
    if (isEmail && !value.toLowerCase().match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      displayMsg("Invalid " + inputType + ", please enter a valid " + inputType, true);
      return false;
    }
    return true;
  }

  /**
   * Displays a message to the user for a specified duration.
   * @param {string} msg - The message to display.
   * @param {boolean} [isError=false] - Whether the message is an error message.
   */
  async function displayMsg(msg, isError = false) {
    const delay = 4;
    const newMsg = gen("p");
    newMsg.innerText = msg;
    if (isError) {
      newMsg.classList.add("error");
    } else {
      newMsg.classList.add("good");
    }
    id("msg-area").appendChild(newMsg);
    await pause(delay);
    id("msg-area").removeChild(newMsg);
  }

  /**
   * Switches the view to the profile view.
   */
  function toProfileView() {
    hide(id("sign-in-view"));
    hide(id("sign-up-view"));
    show(id("profile-view"), "block");
  }

  /**
   * Switches the view away from the profile view.
   */
  function leaveProfileView() {
    show(id("sign-in-view"), "flex");
    hide(id("profile-view"));
  }

  /**
   * Make a request to the ASOS API with the given parameters.
   * Also process the result after the request responded.
   * @param {string} key - the key(s) for the requesr parameter(s).
   * @param {string} value - the value(s) for the request parameter(s).
   * @param {string} URL - the endpoint url that we are sending the request to.
   * @param {string} method - HTTP method being use for this request.
   * @param {boolean} isJson - is the response in the form of JSON?
   * @returns {JSON} JSON representing the request response.
   * @returns {Text} Plain text representing the request response.
   */
  function makeRequest(key, value, URL, method, isJson = true) {
    if (method === "POST") {
      let data = new FormData();
      if (typeof key === "object") {
        for (let i = 0; i < key.length; i++) {
          data.append(key[i], value[i]);
        }
      } else {
        data.append(key, value);
      }
      return fetch(URL, {method: 'POST', body: data})
        .then(statusCheck)
        .then(res => {
          return isJson ? res.json() : res.text();
        })
        .catch(handleError);
    }
    let urlPrep = URL;
    if (key !== null && value !== null) {
      urlPrep += "?" + key + "=" + value;
    } else if (value !== null) {
      urlPrep += value;
    }
    return fetch(urlPrep, {method: 'GET'})
      .then(statusCheck)
      .then(res => {return isJson ? res.json() : res.text();})
      .catch(handleError);
  }

  /**
   * Pause the execution of a function for the given duration.
   * @param {number} secs - the amount of second we want to pause the game.
   * @returns {Promise} a promise that pauses the game until it resolves when
   * the timeout expires.
   */
  function pause(secs) {
    const promise = new Promise(res => {
      setTimeout(() => res("pause for " + secs + " second"), secs * MS_PER_SEC);
    });
    return promise;
  }

  /**
   * Add a event listener to a given element with a given event and function,
   * isOnce is use to indicate if the event listener is only activating
   * once.
   * @param {string} evt - the event the listener is listening for.
   * @param {HTMLElement} elem - the element the listener is attching to.
   * @param {Function} func - the function to run when event is detected.
   * @param {boolean} isOnce - Whether or not the event listener is only activating once.
   */
  function addListen(evt, elem, func, isOnce = false) {
    elem.addEventListener(evt, func, {once: isOnce});
  }

  /**
   * Gets the first instance of the element selected
   * @param {string} selector - HTML query selector
   * @returns {Element} - element associated with the selector
   */
  function qs(selector) {
    return document.querySelector(selector);
  }

  /**
   * Get a element by its id.
   * @param {string} id - id of the element that the user want to get.
   * @returns {HTMLElement} the element that the user want to get.
   * @returns {null} if the element doesn't exist in the DOM.
   */
  function id(id) {
    return document.getElementById(id);
  }

  /**
   * Create a new element by using the given tag name.
   * @param {string} el - tag name of a element.
   * @returns {HTMLElement} that the user want to generate.
   */
  function gen(el) {
    return document.createElement(el);
  }

  /**
   * If there's a error, show the error view and disable all the buttons in the
   * Nav bar.
   * @param {Error} err - error to be thrown
   */
  function handleError(err) {
    displayMsg(err.message, true);
    throw err;
  }

  /**
   * Check the if a response from a request is ok or not.
   * @param {Object} response - the response that is being check.
   * @returns {Object} the same response passed in.
   */
  async function statusCheck(response) {
    if (!response.ok) {
      throw new Error(await response.text());
    }
    return response;
  }

  /**
   * Sets the display style of an HTML element to make it visible.
   *
   * @param {HTMLElement} el - The element to be shown.
   * @param {string} displayType - The CSS display type to apply.
   */
  function show(el, displayType) {
    el.style.display = displayType;
  }

  /**
   * Sets the display style of an HTML element to 'none' to hide it.
   *
   * @param {HTMLElement} el - The element to be hidden.
   */
  function hide(el) {
    el.style.display = "none";
  }

})();