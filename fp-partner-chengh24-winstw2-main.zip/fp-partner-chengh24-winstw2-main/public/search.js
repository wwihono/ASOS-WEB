"use strict";

/**
 * Name: Chengjie Huang, Winston Wihono
 * Date: 05.05.2024
 * Section: CSE 154 AF
 *
 * This JS file handles the funtionality for the search page.
 * On load it check for any search request from other pages, if there is one,
 * execute the search request, if not, do a default search.
 * For each search result, if user click on the button of the search result,
 * it will lead to a detail page for the corresponding product. The user can
 * also add a product to cart by clicking the add to cart button at
 * the search result and the detail page.
 */
(function() {
  window.addEventListener("load", init);

  /**
   * Constants
   */
  const SEARCH_OPTS = {
    method: 'GET',
    headers: {
      'X-RapidAPI-Key': '60323db40bmsheadfcc584a62314p1c5228jsn0b609d0056ae',
      'X-RapidAPI-Host': 'asos2.p.rapidapi.com'
    }
  };
  const MS_PER_SEC = 1000;
  const SECS_TO_PAUSE = 4;

  let curProductID = -1;

  /**
   * Give all add the cart button in the search page event listener
   * that listen for the hover and unhover of the mouse.
   */
  async function init() {
    if (window.sessionStorage.getItem("to-search") !== null) {
      await search(window.sessionStorage.getItem("to-search"));
      window.sessionStorage.removeItem("to-search");
    } else {
      await search();
    }
    if (window.sessionStorage.getItem("to-display") !== null) {
      await enterDetailView(window.sessionStorage.getItem("to-display"));
      window.sessionStorage.removeItem("to-display");
    }
    addListen("click", id("back-btn"), goBack);
    setUpCarousel();
    addListen("input", id("search-box"), toggleSearch);
    addListen("submit", qs("nav form"), (evt) => {
      evt.preventDefault();
      search();
    });
    addListen("click", qs("#add-to-cart button"), addToCart);
  }

  /**
   * Searches for products based on the search term and updates the DOM with the results.
   *
   * @async
   * @param {string} searchTerm - The search term. If null uses search box value
   */
  async function search(searchTerm = null) {
    const res = await fetchListAsos(searchTerm === null ? id("search-box").value : searchTerm);
    removeLoading("search-result");
    id("search-result").innerHTML = "";
    id("search-box").value = "";
    qs("h1").value = "Search";
    if (id("search-result").style.display === "none") {
      toggleDetailView();
    }
    toggleSearch();
    for (let i = 0; i < res.length; i++) {
      id("search-result").appendChild(makeItemCard(res[i]));
    }
  }

  /**
   * Creates an item card element based on the provided item information.
   *
   * @param {Object} info - The information about the item.
   * @returns {HTMLElement} The item card element.
   */
  function makeItemCard(info) {
    const container = gen("article");
    container.classList.add("item");
    container.id = info.id;
    const img = gen("img");
    img.src = "https://" + info.imageUrl;
    img.alt = "Image of " + info.name;
    addListen("click", img, enterDetailView);
    const name = gen("p");
    name.innerText = info.name;
    const price = gen("p");
    price.innerText = info.price.current.text;
    price.classList.add("price");
    const btn = gen("button");
    addListen("mouseenter", btn, setDisplay);
    addListen("mouseleave", btn, resetDisplay);
    addListen("click", btn, addToCart);
    const label = gen("span");
    label.innerText = "Add to Cart";
    label.classList.add("button-txt");
    btn.appendChild(label);
    container.append(img, name, price, btn);
    return container;
  }

  /**
   * Fetches the details of a product from ASOS and enters detailed view of the item.
   *
   * @async
   * @param {string} [outsideId=null] - The ID of the product. If null, uses the parent node's id
   */
  async function enterDetailView(outsideId = null) {
    const id = typeof outsideId === "string" ? outsideId : this.parentElement.id;
    const res = await fetchDetailAsos(id);
    curProductID = id;
    const imgs = res.media.images;
    const carousel = qs("[data-slides]");
    carousel.innerHTML = "";
    const price = qs("#description h3");
    price.innerText = await getPrice(id);
    qs("h1").innerText = res.name;
    processDesc(res.description);
    for (let i = 0; i < imgs.length; i++) {
      const slideItem = gen("li");
      const img = gen("img");
      img.src = "https://" + imgs[i].url;
      slideItem.appendChild(img);
      slideItem.classList.add("slide");
      if (i === 0) {
        slideItem.setAttribute("data-active", "");
      }
      carousel.appendChild(slideItem);
    }
    removeLoading("detail-view");
  }

  /**
   * Adds an item to the cart. If the item is already in the cart, it increases the quantity.
   * If the item is not in the cart, it adds a new entry with a quantity of 1.
   */
  function addToCart() {
    if (id("detail-view").style.display !== "none") {
      addItemDetailView();
    } else {
      const id = this.parentElement.id;
      const children = this.parentElement.children;
      if (window.localStorage.getItem(curProductID) === null) {
        window.localStorage.setItem(id, children[1].innerText + "," + children[2].innerText +
          "," + 1 + "," + children[0].src + "," + children[0].alt);
      } else {
        const params = window.localStorage.getItem(id).split(",");
        window.localStorage.setItem(id, params[0] + "," + params[1] + "," +
          (parseInt(params[2]) + 1) + "," + params[3] + "," + params[4]);
      }
      displayMsg("Added " + 1 + "  " + children[1].innerText + " to cart.");
    }
  }

  /**
   * Handle add a item to cart when user is in the detail view.
   */
  function addItemDetailView() {
    const amount = id("add-to-cart").querySelector("select").value;
    if (amount === "") {
      displayMsg("Please select a quantity to add to the cart.", true);
      return;
    }
    if (window.localStorage.getItem(curProductID) === null) {
      const price = id("description").querySelector("h3").innerText;
      const picUrl = qs("[data-slides]").firstChild.firstChild.src;
      const picAlt = qs("[data-slides]").firstChild.firstChild.alt;
      window.localStorage.setItem(curProductID, qs("h1").innerText + "," +
      price + "," + amount + "," + picUrl + "," + picAlt);
    } else {
      const params = window.localStorage.getItem(curProductID).split(",");
      window.localStorage.setItem(curProductID, params[0] + "," + params[1] + "," +
        (parseInt(params[2]) + parseInt(amount)) + "," + params[3] + "," + params[4]);
    }
    id("add-to-cart").querySelector("select").value = "";
    displayMsg("Added " + amount + "  " + qs("h1").innerText + " to cart.");
  }

  /**
   * Fetches a list of products from ASOS based on the provided filters.
   *
   * @async
   * @param {string} [query=null] - The search query.
   * @param {number} [maxPrice=null] - The maximum price filter.
   * @param {number} [minPrice=null] - The minimum price filter.
   * @param {string} [color=null] - The color filter.
   * @param {string} [brand=null] - The brand filter.
   * @returns {Promise<Array>} A promise that resolves to an array of products.
   */
  async function fetchListAsos(
    query = null,
    maxPrice = null,
    minPrice = null,
    color = null,
    brand = null
  ) {
    const fixQuery = query === null ? "" : "&q=" + query;
    const maxP = maxPrice === null ? "" : "&priceMax=" + maxPrice;
    const minP = minPrice === null ? "" : "&priceMin=" + minPrice;
    const fixColor = color === null ? "" : "&base_colour=" + color;
    const fixBrand = brand === null ? "" : "&brand=" + brand;
    const AsosURL = "https://asos2.p.rapidapi.com/products/v2/list?store=US&offset=0" +
    "&categoryId=4209&limit=100" + minP + "&country=US&sort=freshness" + fixQuery + fixColor +
    "&currency=USD" + maxP + "&sizeSchema=US" + fixBrand + "&lang=en-US";
    try {
      displayLoading();
      const response = await fetch(AsosURL, SEARCH_OPTS);
      const validate = await statusCheck(response);
      const initialResult = await validate.json();
      return initialResult.products;
    } catch (err) {
      handleError(err);
    }
  }

  /**
   * Fetches the details of a product from an API.
   *
   * @async
   * @param {string} id - The ID of the product.
   * @returns {Promise<json>} json object containing item data
   */
  async function fetchDetailAsos(id) {
    const url = "https://asos2.p.rapidapi.com/products/v4/detail?id=" + id + "&lang=en-US&store=US&sizeSchema=US&currency=USD";
    try {
      displayLoading();
      const response = await fetch(url, SEARCH_OPTS);
      await statusCheck(response);
      return await response.json();
    } catch (err) {
      handleError(err);
    }
  }

  /**
   * Fetches the price of a product from an API.
   *
   * @async
   * @param {string} id - The ID of the product.
   * @returns {Promise<string>} The price of the product.
   */
  async function getPrice(id) {
    try {
      let res = await fetch(
        "https://asos2.p.rapidapi.com/products/v4/get-stock-price?productIds=" + id + "&lang=en-US&store=US&sizeSchema=US&currency=USD",
        SEARCH_OPTS
      );
      await statusCheck(res);
      res = await res.json();
      res = res[0].productPrice.current.text;
      return res;
    } catch (error) {
      handleError(error);
    }
  }

  /**
   * Processes the description of a product and updates the DOM.
   *
   * @param {string} desc - The raw description of the product.
   */
  function processDesc(desc) {
    let processedTexts = desc.replace(/<a .*?>/g, "")
      .replace(/<\/a>/g, "")
      .replace(/<a*>/g, "")
      .replaceAll("<strong>", "")
      .replace(/<\/strong>/g, "")
      .replace(/<[^>]*>/g, "!")
      .replace(/!{2,}/g, "?")
      .split("?");

    const title = qs("#description h2");
    const descList = qs("#description ul");
    descList.innerHTML = "";
    title.innerText = processedTexts[0];
    for (let i = 1; i < processedTexts.length - 1; i++) {
      const descItem = gen("li");
      descItem.innerText = processedTexts[i];
      descList.appendChild(descItem);
    }
  }

  /**
   * Toggles the detail view and search result view.
   */
  function toggleDetailView() {
    if (id("search-result").style.display === "none") {
      show(id("search-result"), "flex");
      hide(id("detail-view"));
    } else {
      show(id("detail-view", "block"));
      hide(id("search-result"));
    }
  }

  /**
   * Displays a loading spinner and hides other views.
   */
  function displayLoading() {
    hide(id("detail-view"));
    hide(id("search-result"));
    show(id("loading"), "block");
  }

  /**
   * Removes the loading spinner and optionally shows a specified view.
   *
   * @param {string} [backTo=null] - The ID of the view to show. If null, no view is shown.
   */
  function removeLoading(backTo = null) {
    hide(id("loading"));
    if (backTo !== null) {
      if (backTo === "detail-view") {
        show(id(backTo), "block");
        hide(id("search-result"));
      } else {
        show(id(backTo), "flex");
        hide(id("detail-view"));
      }
    }
  }

  /**
   * Disable or enable the seach button based on the content in
   * the search input.
   */
  function toggleSearch() {
    const searchInput = id("search-box");
    const searchBtn = id("search-btn");
    if (searchInput.value.trim() === "") {
      searchBtn.disabled = true;
      searchBtn.style.opacity = 0.33;
    } else {
      searchBtn.disabled = false;
      searchBtn.style.opacity = 1;
    }
  }

  /**
   * Configure the functionality for detail view's picture
   * carousel
   */
  function setUpCarousel() {
    const buttons = qsa(".carousel-btn");
    buttons.forEach(btn => {
      addListen("click", btn, () => {
        slideButtonSetup(btn);
      });
    });
  }

  /**
   * Sets up the carousel slide button functionality.
   * Moves to the next or previous slide based on the button clicked.
   *
   * @param {HTMLElement} button - The button element that triggers the slide change.
   */
  function slideButtonSetup(button) {
    const offset = button.dataset.carouselButton === "next" ? 1 : -1;
    const slides = button.closest("[data-carousel]").querySelector("[data-slides]");
    const activeSlide = slides.querySelector("[data-active]");
    let newIndex = [...slides.children].indexOf(activeSlide) + offset;
    if (newIndex < 0) {
      newIndex = slides.children.length - 1;
    }
    if (newIndex >= slides.children.length) {
      newIndex = 0;
    }
    slides.children[newIndex].dataset.active = true;
    delete activeSlide.dataset.active;
  }

  /**
   * Display the given message in the message area for 4 seconds. The background
   * is red if isError is true, green if it is false.
   * @param {Error} msg - the message to display.
   * @param {Boolean} isError - whether it is displaying a error or not.
   */
  async function displayMsg(msg, isError = false) {
    const newMsg = gen("p");
    newMsg.innerText = msg;
    if (isError) {
      newMsg.classList.add("error");
    } else {
      newMsg.classList.add("good");
    }
    id("msg-area").appendChild(newMsg);
    await pause(SECS_TO_PAUSE);
    id("msg-area").removeChild(newMsg);
  }

  /**
   * Pause the execution of a function for the given duration.
   * @param {number} secs - the amount of second we want to pause the game.
   * @returns {Promise} a promise that pauses the game until it resolves when
   * the timeout expires.
   */
  function pause(secs) {
    const promise = new Promise(res => {
      setTimeout(() => res("pause for " + secs + " second"), secs * MS_PER_SEC);
    });
    return promise;
  }

  /**
   * Resets the view and search bar when navigating back from the detail view.
   */
  function goBack() {
    toggleDetailView();
    id("add-to-cart").querySelector("select").value = "";
    qs("h1").innerText = "Search";
  }

  /**
   * Sets the display style of an HTML element to make it visible.
   *
   * @param {HTMLElement} el - The element to be shown.
   * @param {string} displayType - The CSS display type to apply.
   */
  function show(el, displayType) {
    el.style.display = displayType;
  }

  /**
   * Sets the display style of an HTML element to 'none' to hide it.
   *
   * @param {HTMLElement} el - The element to be hidden.
   */
  function hide(el) {
    el.style.display = "none";
  }

  /**
   * Set the button content to a shopping cart image.
   */
  function setDisplay() {
    this.children[0].classList.add("material-symbols-outlined");
    this.children[0].firstChild.textContent = "add_shopping_cart";
  }

  /**
   * Set the button content to "Add to Cart" text.
   */
  function resetDisplay() {
    this.children[0].classList.remove("material-symbols-outlined");
    this.children[0].firstChild.textContent = "Add to Cart";
  }

  /**
   * Gets the first instance of the element selected
   * @param {string} selector - HTML query selector
   * @returns {Element} - element associated with the selector
   */
  function qs(selector) {
    return document.querySelector(selector);
  }

  /**
   * Gets the all instance of the element selected
   * @param {string} selector - HTML query selector
   * @returns {Element} - element associated with the selector
   */
  function qsa(selector) {
    return document.querySelectorAll(selector);
  }

  /**
   * Create a new element by using the given tag name.
   * @param {string} el - tag name of a element.
   * @returns {HTMLElement} that the user want to generate.
   */
  function gen(el) {
    return document.createElement(el);
  }

  /**
   * Add a event listener to a given element with a given event and function,
   * isOnce is use to indicate if the event listener is only activating once.
   * @param {string} evt - the event the listener is listening for
   * @param {HTMLElement} elem - the element the listener is attching to
   * @param {Function} func - the function to run when event is detected
   * @param {boolean} isOnce - whether or not the event listener is only activating once
   */
  function addListen(evt, elem, func, isOnce = false) {
    elem.addEventListener(evt, func, {once: isOnce});
  }

  /**
   * Logs errors to the console and displays an error message
   * This function is typically used to handle exceptions and display user-friendly error messages
   * when network requests or other critical operations fail.
   * @param {Error} error - The error object that contains information about the error encountered.
   */
  function handleError(error) {
    console.error("Failed to fetch data: ", error);
    displayMsg(error.message, true);
  }

  /**
   * Get a element by its id.
   * @param {string} id - id of the element that the user want to get.
   * @returns {HTMLElement} the element that the user want to get.
   * @returns {null} if the element doesn't exist in the DOM.
   */
  function id(id) {
    return document.getElementById(id);
  }

  /**
   * Checks the response status of a fetch request. If the response is not 'ok', it throws an
   * error with the response text. Otherwise, it returns the unchanged response. This function is
   * typically used to validate responses in the context of asynchronous operations that involve
   * fetch requests.
   * @param {Response} res - The response object from a fetch request.
   * @returns {Promise<Response>} A promise that resolves with the original response if it is 'ok',
   * otherwise throws an error.
   * @async
   * @throws {Error} Throws an error if the response is not 'ok'.
   */
  async function statusCheck(res) {
    if (!res.ok) {
      throw new Error(await res.text());
    }
    return res;
  }
})();