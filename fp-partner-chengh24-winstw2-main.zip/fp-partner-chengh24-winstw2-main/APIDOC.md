## Login with user entered
**Request Format:** `/login`

**Request Type:** POST

**Returned Data Format**: text

**Description:** Verify the given user login information against the corresponding user information stored on the server.

**Example Request:** `/login` with `username="user1"` and `password="12345"`


**Example Response:**

```
login success
```

**Error Handling:**
- Error 500 (plain text): "Server side error"
- Error 400 (plain text): "Missing username, please enter username"
- Error 400 (plain text): "Missing password, please enter password"
- Error 400 (plain text): "Invalid username or password"

## Logoff a user
**Request Format:** `/logoff`

**Request Type:** POST

**Returned Data Format**: text

**Description:** Logs off the given user if they are currently logged in.

**Example Request:**  `/logoff` with `username="user1"`

**Example Response:**

```
User logged off
```

**Error Handling:**
- Error 500 (plain text): "Server side error"
- Error 400 (plain text): "Missing username, please enter username"
- Error 400 (plain text): "Missing password, please enter password"
- Error 400 (plain text): "User already logged off"

## register a new user to server
**Request Format:** `/register`

**Request Type:** POST

**Returned Data Format**: text

**Description:** Register a new user account and store the information in the database

**Example Request:** `/register` with `username="user1"`, `password="12345"`, and `email="user1@example.com"`

**Example Response:**

```
user registered successfully
```

**Error Handling:**
- Error 500 (plain text): "Something went wrong on the server"
- Error 400 (plain text): "Missing username, please enter username"
- Error 400 (plain text): "Missing password, please enter password"
- Error 400 (plain text): "Missing email, please enter email"
- Error 400 (plain text): "User already exists"

## Get user information
**Request Format:** `/userInfo/:user`

**Request Type:** GET

**Returned Data Format**: JSON

**Description:** Retrieve user information based on the provided username.

**Example Request:** `/userInfo/user1`

**Example Response:**
```json
{
  "username": "user1",
  "email": "user1@example.com"
}
```
**Error Handling:**- 
- Error 500 (plain text): "Something went wrong on the server"
- Error 400 (plain text): "Missing username, please provide a username"
- Error 400 (plain text): "User doesn't exist"

## Add to purchase history
**Request Format:** `/addToHistory`

**Request Type:** POST

**Returned Data Format**: text

**Description:** Adds successful purchases to the server-side purchase history and updates the analytics table.

**Example Request:** `/addToHistory` with `price=29.99`, `name="ItemName"`, `amount=2`, `username="user1"`, and `id=123`

**Example Response:**
```
Added to purchase history
```

**Error Handling:**
- Error 500 (plain text): "Something went wrong on the server"
- Error 400 (plain text): "Missing one or more parameters"
- Error 400 (plain text): "Not logged in"

## Retrieve a specific user's purchase history
**Request Format:** `/retrieveHistory`

**Request Type:** POST

**Returned Data Format**: JSON

**Description:** Retrieves the purchase history for a specific user.

**Example Request:** `/retrieveHistory` with `user="user1"`

**Example Response:**
```json
[
  {
    "username": "user1",
    "name": "ItemName",
    "price": 29.99,
    "amount": 2,
    "date": "2023-06-01T00:00:00.000Z"
  },
  ...
]
```
**Error Handling:**
- Error 500 (plain text): "Something went wrong on the server"
- Error 400 (plain text): "Missing Username."
- Error 400 (plain text): "Please login to view transaction history"

## Retrieve a specific user's most recent purchase history
**Request Format:** `/retrieveHistoryNewest`

**Request Type:** POST

**Returned Data Format**: JSON

**Description:** Retrieves the purchase history ordered by most recent for a specific user.

**Example Request:** `/retrieveHistory` with `user="user1"`

**Example Response:**
```json
[
  {
    "username": "user1",
    "name": "ItemName",
    "price": 29.99,
    "amount": 2,
    "date": "2023-06-01T00:00:00.000Z"
  },
  {
    "username": "user1",
    "name": "ItemName",
    "price": 29.99,
    "amount": 2,
    "date": "2023-07-01T00:00:00.000Z"
  }
  ...
]
```
**Error Handling:**
- Error 500 (plain text): "Something went wrong on the server"
- Error 400 (plain text): "Missing Username."
- Error 400 (plain text): "Please login to view transaction history"

## Retrieve item purchase analytics
**Request Format:** `/retrieveAnalytics`

**Request Type:** GET

**Returned Data Format**: JSON

**Description:** Retrieves the number of times all items has been purchased.

**Example Request:** `/retrieveAnalytics`

**Example Response:**
```json
{
  "123": 15,
  "094": 123
}
```
**Error Handling:**

- Error 500 (plain text): "Something went wrong on the server"
- Error 400 (plain text): "Missing one or more parameters"
- Error 400 (plain text): "Item not found"